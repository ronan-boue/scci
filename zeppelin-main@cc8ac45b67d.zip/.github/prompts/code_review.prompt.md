---
mode: ['agent']
name: 'Code review last commits'
tools: ['codebase', 'sonarqube', 'test-automation']
description: 'Code review rules of the last commits for ACDC Team'
---

Perform a comprehensive code review of the last commits made by the ACDC Team.
I want a complete and thorough analysis of the code focusing on code quality, design patterns, and architectural principles.
Make sure to include code snippets and examples where necessary.

## Code Review Focus Areas:

### Code Quality Assessment:
- **Code Smells Detection**: Identify common code smells such as:
  - Long methods/classes
  - Duplicate code
  - Dead code
  - Magic numbers/strings
  - God objects
  - Feature envy
  - Data clumps
  - Shotgun surgery
  - Inappropriate intimacy

### Anti-Patterns Identification:
- Detect and report anti-patterns such as:
  - Spaghetti code
  - God class
  - Singleton abuse
  - Copy-paste programming
  - Hard coding
  - Poltergeist classes
  - Golden hammer
  - Lava flow

### Design Patterns Analysis:
- **GOF (Gang of Four) Patterns**: Evaluate and suggest appropriate design patterns:
  - **Creational**: Factory, Abstract Factory, Builder, Prototype, Singleton
  - **Structural**: Adapter, Bridge, Composite, Decorator, Facade, Flyweight, Proxy
  - **Behavioral**: Chain of Responsibility, Command, Iterator, Mediator, Memento, Observer, State, Strategy, Template Method, Visitor

### SOLID Principles Evaluation:
- **S**ingle Responsibility Principle (SRP)
- **O**pen/Closed Principle (OCP)
- **L**iskov Substitution Principle (LSP)
- **I**nterface Segregation Principle (ISP)
- **D**ependency Inversion Principle (DIP)

### Additional Architectural Principles:
- DRY (Don't Repeat Yourself)
- KISS (Keep It Simple, Stupid)
- YAGNI (You Aren't Gonna Need It)
- Clean Code principles
- Separation of Concerns

## Code Review Report Structure:

The code review should include the following sections:
* **Introduction**
* **Methodology**
* **Code Quality Analysis**
  - Code smells detected
  - Anti-patterns identified
  - Severity assessment
* **Design Patterns Assessment**
  - Current patterns usage
  - Missing pattern opportunities
  - Pattern misuse identification
* **SOLID Principles Compliance**
  - Violations identified
  - Compliance score per principle
  - Specific recommendations
* **Architecture and Design Improvements**
  - Structural improvements
  - Refactoring suggestions
  - Design pattern recommendations
* **Test Coverage and Unit Testing Verification**
* **Complexity Analysis**
  - Cyclomatic complexity
  - Cognitive complexity
  - Maintainability index
* **Performance Analysis**
* **Security Considerations**
* **Specific Code Improvement Recommendations**
  - Priority-based suggestions
  - Implementation guidelines
  - Before/after code examples
* **Technical Debt Assessment**
* **Conclusion**
* **Action Plan**
* **References**

## Output Requirements:
- Output in French
- Include specific code snippets with line numbers when possible
- Provide severity levels for identified issues (Critical, High, Medium, Low)
- Suggest concrete refactoring steps
- Prioritize recommendations based on impact and effort
- Include estimated effort for each recommendation

Output in french. The output document should go under the 'docs' folder at the root of the project.
If the 'docs' folder does not exist, create it.
- Ensure the report is well-structured and easy to navigate
- Use headings, subheadings, and bullet points for clarity
- Include a table of contents for easy navigation
- Use code blocks for code snippets
- Ensure the report is comprehensive and actionable
- Provide a summary of key findings and recommendations at the end
- Ensure the report is suitable for both developers and project managers
- Use a professional and formal tone

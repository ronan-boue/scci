python3 test_pub.py -f /app/share/PEPC/data/zigbee.json

# send a payload to the MQTT broker
# used to test Cloud2Edge connectivity (module direct method)
mosquitto_pub -t rci-c2e -f message1.json

docker image load < synciot-rci.tar

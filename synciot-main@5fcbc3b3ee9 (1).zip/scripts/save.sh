docker image save synciot-rci > synciot-rci.tar

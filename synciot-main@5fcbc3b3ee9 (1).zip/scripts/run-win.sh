# winpty docker run -it --rm -v //c/Share/SCCI/modules:/config synciot-rci bash
winpty docker run -d --rm -v //c/Share/SCCI/modules:/config synciot-rci

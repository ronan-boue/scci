docker run -d -p 80:80 --name synciot -e CONFIG_FILENAME=/config/synciot.json synciot-rci:latest

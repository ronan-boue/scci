export CONFIG_FILENAME=/config/test/test-zeppelin-v2.json
cd ..
python3 zeppelin.py

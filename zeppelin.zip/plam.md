# Architecture du Projet Zeppelin

## Vue d'ensemble

**Zeppelin** (Zone d'Examen et de Préparation des Publications pour l'Extraction et la Légitimation des Informations Normalisées) est un module de validation et normalisation de données IoT pour différent projet nécessitant des communications Azure IoT.

Le système est conçu selon une architecture de **pipelines** et de **processeurs**, permettant de recevoir des messages de différentes sources, de les valider, les normaliser et les republier vers des destinations configurées.

## Architecture Générale

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Sources       │    │    Zeppelin      │    │  Destinations   │
│                 │    │                  │    │                 │
│ ┌─────────────┐ │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ │ IoT Devices │ │────┤ │ Processors   │ ├────┤ │ IoT Edge    │ │
│ │ MQTT Broker │ │    │ │ - Validation │ │    │ │ MQTT Broker │ │
│ │ Cloud (C2D) │ │    │ │ - Transform. │ │    │ │ IoT Hub     │ │
│ │ IoT Edge    │ │    │ │ - Routing    │ │    │ │ Cloud       │ │
│ └─────────────┘ │    │ └──────────────┘ │    │ └─────────────┘ │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                              │
                              ▼
                      ┌──────────────┐
                      │  Prometheus  │
                      │   Metrics    │
                      └──────────────┘
```

## Composants Principaux

### 1. Module Principal (zeppelin.py)

Le module principal `src/zeppelin.py` est responsable de :
- **Chargement de la configuration** dynamique depuis `/config/zeppelin.json`
- **Instanciation des processeurs** via la ProcessorFactory
- **Gestion du cycle de vie** des pipelines
- **Surveillance de la configuration** avec rechargement automatique
- **Exposition des métriques** Prometheus

**Fonctionnalités clés :**
- Configuration hot-reload (surveillance de fichiers)
- Gestion multi-thread des processeurs
- Monitoring des métriques via Prometheus

### 2. Architecture des Pipelines

Chaque **pipeline** définit :
- **Source broker** (point d'entrée des données)
- **Destination broker** (point de sortie des données)
- **Processeur** (logique de validation/transformation)
- **Configuration** (schémas JSON, règles de validation)

**Structure d'un pipeline :**
```json
{
  "name": "nom_pipeline",
  "class": "type_processeur",
  "json_schema": "chemin/vers/schema.json",
  "source_broker": {
    "class": "type_source",
    "topic": "topic_source",
    "mqtt": { /* config MQTT */ }
  },
  "destination_broker": {
    "class": "type_destination", 
    "topic": "topic_destination"
  },
  "cloud_event": { /* format CloudEvent */ }
}
```

### 3. Agents de Communication (communication/)

#### Architecture des Agents
```
CommunicationInterface (Interface)
├── IoTDeviceAgent (Cloud-to-Device)
├── IoTEdgeAgent (Edge Hub)
├── IoTHubAgent (Cloud-to-Edge)
├── MqttAgent (MQTT Standard)
└── VoidAgent (Test/Debug)
```

#### Types d'Agents Supportés

**a) IoTDeviceAgent (`class: iotdevice`)**
- Se présente comme un device au IoT Hub
- Utilise la connection string de `/etc/aziot/config.toml`
- **Usage :** Communication Cloud-to-Device
- **Fiabilité :** Limitée (pas de confirmation)

**b) IoTEdgeAgent (`class: iotedge`)**
- Interface avec Azure IoT Edge Hub
- Support des Direct Methods pour Cloud-to-Edge
- **Usage :** Communication bidirectionnelle Edge
- **Singleton :** Une seule instance par processus

**c) IoTHubAgent (`class: iothub`)**
- Client IoT Hub pour communications Cloud-to-Edge
- Utilise les Direct Methods vers les modules Edge
- **Usage :** Communication Cloud vers Edge (fiable)
- **Configuration :** Via `IOTHUB_CONNECTION_STRING`

**d) MqttAgent (`class: mqtt`)**
- Client MQTT standard (Mosquitto)
- Support TLS/SSL et authentification
- **Usage :** Communication MQTT classique
- **Features :** Reconnexion automatique, QoS configurable

#### Factory Pattern
La `CommunicationFactory` instancie les agents selon la configuration :
```python
agent = CommunicationFactory.get_client(config)
```

### 4. Processeurs (processors/)

#### Architecture des Processeurs
```
ProcessorInterface (Interface)
├── BaseProcessor (Classe de base)
    ├── GenericProcessor (Données génériques)
    ├── EgaugeProcessor (Compteurs eGauge)
    ├── ZigbeeProcessor (Devices Zigbee)
    ├── C2DProcessor (Cloud-to-Device)
    ├── RCIProcessor (Données RCI)
    ├── RCICommandProcessor (Commandes RCI)
    └── IBR/
        ├── IBRProcessor (Données IBR)
        └── GDPProcessor (Données GDP)
```

#### Processeur de Base (BaseProcessor)

**Cycle de traitement :**
1. **Assess** : Validation initiale (CloudEvent, format)
2. **Validate** : Validation contre schéma JSON
3. **Normalize** : Transformation/normalisation des données
4. **Publish** : Publication vers destination

**Fonctionnalités :**
- **Threading** : Chaque processeur s'exécute dans son propre thread
- **Queue management** : Gestion des messages entrants
- **Schema validation** : Validation JSON Schema
- **Rules processing** : Application de règles métier
- **Cloud Event** : Support du format CloudEvent 1.0

#### Processeurs Spécialisés

**GenericProcessor**
- Traitement de données génériques au format CloudEvent
- Validation configurable par `data_types`
- Population d'attributs CloudEvent

**EgaugeProcessor**
- Traitement des données de compteurs eGauge
- Validation des valeurs et unités
- Device model : 'egauge'

**ZigbeeProcessor**
- Traitement des devices Zigbee
- Configuration dynamique par modèle de device
- Normalisation basée sur `config/zigbee.json`

**C2DProcessor (Cloud-to-Device)**
- Routage des messages du cloud vers Edge
- Support des propriétés de routage (`dest_topic`)
- Pas de transformation des données

**RCIProcessor/RCICommandProcessor**
- Traitement des données/commandes RCI
- Validation des types de données numériques
- Support du routage par device_id

**IBRProcessor/GDPProcessor**
- Traitement des données IBR et GDP
- Types de données validés
- Support de la compression et base64

### 5. Système de Métriques (metrics.py)

**Métriques Prometheus exposées :**

```python
# Métriques générales
zeppelin_rx_message_total         # Messages reçus
zeppelin_rx_message_valid         # Messages valides
zeppelin_rx_message_invalid       # Messages invalides  
zeppelin_rx_message_error         # Erreurs de traitement
zeppelin_tx_message_total         # Messages transmis
zeppelin_throttle_total           # Throttling appliqué

# Métriques par type
zeppelin_rx_zigbee_message_total  # Messages Zigbee
zeppelin_rx_egauge_message_total  # Messages eGauge
zeppelin_rx_c2d_message_total     # Messages Cloud-to-Device
zeppelin_rx_gdp_message_total     # Messages GDP
zeppelin_rx_ibr_message_total     # Messages IBR
zeppelin_rx_rci_message_total     # Messages RCI
zeppelin_rx_generic_message_total # Messages génériques
```

**Serveur Prometheus :**
- Port par défaut : 8000 (configurable via `PROMETHEUS_PORT`)
- Métriques thread-safe
- Démarrage automatique avec Zeppelin

### 6. Configuration

#### Structure de Configuration
```
config/
├── zeppelin.json              # Configuration principale
├── zeppelin-mqtt.json         # Config MQTT
├── zeppelin-gdp.json          # Config GDP
├── zigbee.json               # Config Zigbee devices
├── schemas/                  # Schémas JSON validation
│   ├── egauge-schema.json
│   ├── gdp-schema.json
│   └── zigbee-schema.json
└── exemples/                 # Exemples de configuration
    ├── zeppelin-iotedge-rci.json
    └── zeppelin-iothub-rci.json
```

#### Configuration Dynamique
- **Hot-reload** : Surveillance automatique des fichiers
- **Validation** : Validation de la configuration au chargement
- **Flexibilité** : Support de multiples environnements

### 7. Patterns de Communication

#### Cloud-to-Device (C2D)
```
Cloud IoT Hub → IoTDeviceAgent → C2DProcessor → IoTEdgeAgent → Edge
```
- **Usage :** Messages du cloud vers Edge
- **Fiabilité :** Limitée (best effort)
- **Configuration :** Via aziot config

#### Cloud-to-Edge (C2E) 
```
Cloud → IoTHubAgent → [Direct Method] → IoTEdgeAgent → Edge
```
- **Usage :** Commandes fiables cloud vers Edge
- **Fiabilité :** Haute (avec confirmation)
- **Méthode :** Direct Methods Azure IoT

#### MQTT Standard
```
Source → MqttAgent → Processeur → MqttAgent → Destination
```
- **Usage :** Communication MQTT classique
- **Brokers :** Mosquitto, Eclipse, etc.
- **Features :** TLS, Auth, QoS

### 8. Gestion des Erreurs et Monitoring

#### Stratégies de Résilience
- **Reconnexion automatique** pour tous les agents
- **Retry logic** avec backoff exponentiel
- **Throttling** configurable par pipeline
- **Dead letter handling** via métriques

#### Monitoring
- **Health checks** via métriques Prometheus
- **Log centralisé** avec niveaux configurables
- **Alerting** sur métriques d'erreur
- **Dashboard** Prometheus/Grafana

## Flux de Données Typiques

### 1. Pipeline Zigbee
```
Zigbee Device → MQTT → IoTEdgeAgent → ZigbeeProcessor → IoTEdgeAgent → Normalized Topic
```

### 2. Pipeline eGauge
```
eGauge Modbus → MQTT → IoTEdgeAgent → EgaugeProcessor → IoTEdgeAgent → Normalized Topic
```

### 3. Pipeline Cloud-to-Device
```
Cloud Command → IoTDeviceAgent → C2DProcessor → IoTEdgeAgent → Target Module
```

### 4. Pipeline RCI Command
```
Cloud → IoTHubAgent → [Direct Method] → IoTEdgeAgent → RCICommandProcessor → Target Device
```

## Déploiement et Containerisation

### Docker Support
```
docker/
├── Dockerfile.iotedge.amd64     # Image pour IoT Edge
├── Dockerfile.test.mqtt.amd64   # Image de test MQTT
├── Dockerfile.test.v2.amd64     # Image de test v2
└── test/
    └── docker-compose.yml       # Composition de test
```

### Scripts de Build
```
scripts/
├── build.sh           # Build principal
├── build-test.sh      # Build de test
├── run.sh            # Exécution standard
└── run-test-v2.sh    # Test version 2
```

## Évolutions et Extensibilité

### Ajout d'un Nouveau Processeur
1. Hériter de `BaseProcessor`
2. Implémenter `assess()`, `validate()`, `normalize()`
3. Ajouter à `ProcessorFactory`
4. Créer schéma JSON si nécessaire

### Ajout d'un Nouvel Agent
1. Implémenter `CommunicationInterface`
2. Ajouter à `CommunicationFactory`
3. Configurer throttling et métriques
4. Tests d'intégration

### Configuration de Nouvelles Sources
1. Définir pipeline dans `zeppelin.json`
2. Créer schéma de validation
3. Configurer règles métier
4. Tester avec données réelles

## Bonnes Pratiques

### Configuration
- Utiliser des schémas JSON pour validation
- Configurer throttling approprié
- Monitorer les métriques de performance
- Tester la configuration en environnement contrôlé

### Développement
- Respecter l'interface des processeurs
- Implémenter gestion d'erreurs robuste
- Ajouter métriques spécifiques au processeur
- Maintenir compatibilité CloudEvent

### Opérations
- Surveiller métriques Prometheus
- Configurer alertes sur erreurs
- Maintenir logs centralisés
- Planifier tests de charge

Cette architecture modulaire et extensible permet à Zeppelin de gérer efficacement la validation et normalisation des données IoT tout en maintenant la flexibilité nécessaire pour s'adapter à de nouveaux types de sources et de destinations.